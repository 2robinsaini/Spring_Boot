package com.robin.school.management.spring.boot.jsp;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the student database table.
 * 
 */
@Entity
@NamedQuery(name="Student.findAll", query="SELECT s FROM Student s")
public class Student implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int rollNumber;

	@Lob
	private byte[] address;

	private String name;

	public Student() {
	}

	public int getRollNumber() {
		return this.rollNumber;
	}

	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}

	public byte[] getAddress() {
		return this.address;
	}

	public void setAddress(byte[] address) {
		this.address = address;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}