package com.robin.school.management.spring.boot.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.robin.school.management.spring.boot.jsp.Student;

@Repository
public class StudentDaoImpl  implements StudentDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<Student> getStudentList() {
		
		List<Student> stdList = sessionFactory.openSession().createCriteria(Student.class).list();
		
		return stdList;
	}

}
