package com.robin.school.management.spring.boot.jsp;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;

@Configuration
public class BeanConfig {

	/*
	 * @Autowired private EntityManagerFactory entityManagerFactory;
	 * 
	 * @Bean public SessionFactory getSessionFactory() { if
	 * (entityManagerFactory.unwrap(SessionFactory.class) == null) { throw new
	 * NullPointerException("factory is not a hibernate factory"); } return
	 * entityManagerFactory.unwrap(SessionFactory.class); }
	 */
	
	 @Autowired
	    Environment environment;
	 
	    @Bean
	    public LocalSessionFactoryBean sessionFactory() {
	        LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
	        sessionFactory.setDataSource(dataSource());
	        sessionFactory.setPackagesToScan("com.robin.school.management.spring.boot.jsp");
	        sessionFactory.setAnnotatedClasses(Student.class);
	        sessionFactory.setHibernateProperties(hibernateProperties());
	        return sessionFactory;
	    }
	 
	    private Properties hibernateProperties() {
	        Properties properties = new Properties();
	        properties.put("hibernate.dialect", environment.getRequiredProperty("spring.jpa.properties.hibernate.dialect"));
	        properties.put("hibernate.show_sql", environment.getRequiredProperty("spring.jpa.show_sql"));
	        properties.put("hibernate.format_sql", environment.getRequiredProperty("hibernate.format_sql"));
	        return properties; 
	    }
	 
	    @Bean
	    public DataSource dataSource() {
	        DriverManagerDataSource dataSource = new DriverManagerDataSource();
	        dataSource.setDriverClassName(environment.getRequiredProperty("jdbc.driverClassName"));
	        dataSource.setUrl(environment.getRequiredProperty("spring.datasource.username.url"));
	        dataSource.setUsername(environment.getRequiredProperty("spring.datasource.username.username"));
	        dataSource.setPassword(environment.getRequiredProperty("spring.datasource.username.password"));
	        return dataSource;
	    }
	     
	    @Bean
	    @Autowired
	    public HibernateTransactionManager transactionManager(SessionFactory s) {
	        HibernateTransactionManager txManager = new HibernateTransactionManager();
	        txManager.setSessionFactory(s);
	        return txManager;
	    }
	}
	
	

