package com.robin.school.management.spring.boot.service;

import java.util.List;

import com.robin.school.management.spring.boot.jsp.Student;

public interface StudentService {

	List<Student> getStudentList();

}
