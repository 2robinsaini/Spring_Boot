package com.robin.school.management.spring.boot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.robin.school.management.spring.boot.dao.StudentDao;
import com.robin.school.management.spring.boot.jsp.Student;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentDao stdDao;
	
	@Override
	public List<Student> getStudentList() {
		return stdDao.getStudentList();
	}

}
