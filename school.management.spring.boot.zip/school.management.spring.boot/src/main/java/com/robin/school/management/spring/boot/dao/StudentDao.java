package com.robin.school.management.spring.boot.dao;

import java.util.List;

import com.robin.school.management.spring.boot.jsp.Student;

public interface StudentDao {

	List<Student> getStudentList();

}
